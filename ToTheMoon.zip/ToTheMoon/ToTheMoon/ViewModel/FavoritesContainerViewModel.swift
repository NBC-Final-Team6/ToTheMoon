//
//  Untitled.swift
//  ToTheMoon
//
//  Created by 황석범 on 2/1/25.
//

import RxSwift
import RxCocoa

final class FavoritesContainerViewModel {
    let showSearchViewController = PublishRelay<Void>()
}

//
//  Coin+CoreDataClass.swift
//  ToTheMoon
//
//  Created by 강민성 on 1/22/25.
//
//

import Foundation
import CoreData

@objc(Coin)
public class Coin: NSManagedObject {

}
